#예외 클래스 (사용자정의 예외)

class TooBigNumError(Exception):
    def __init__(self,val):
        self.val = val

    def __str__(self):
        return 'too big number {}. Use 1~10'.format(self.val)



print("프로그램 시작")
print('프로그램 종료')



def user_defined_exception_test():
    num = int(input('1부터 10 사이의 점수를 입력하세요! : '))   # 숫자 입력
    if num > 10:
        raise TooBigNumError(num)                              # 에러 발생 -> #강제로 exception 발생 -> raise 키워드 (exception 을 강제로 불러온다.)
    print('숫자 {} 를 입력하셨군요! '.format(num))             # 정상인 경우 출력문


user_defined_exception_test()


#이런식으로 class 에 exception 발생할때 만들어두고
# def 에서 class 를 호출해서 쓰면 좋다.