try:
    print('안녕하세요')
    print(param)
    print("안녕하세요2")

except Exception as err:
    print('예외가 발생했습니다')
    print('Error :', err)
