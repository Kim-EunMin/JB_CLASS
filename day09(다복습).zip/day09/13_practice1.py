#엑셀파일생성
import openpyxl
# excel_file = 'data/임직원.xlsx'
# wb = openpyxl.Workbook()
# ws = wb.active
# ws.title = '전북은행'
#
# ws['A1'] = '사번'
# ws['B1'] = '이름'
# ws['C1'] = '부서명'
# ws['D1'] = '연락처'
# ws['E1'] = '이메일'
#
# ws.append([ 201 ,'한혜형', '디지털영업팀', '010-5678-1111', 'aa@jbbank.com'])
# ws.append([ 202 ,'김영목', '카드사업부', '010-5678-2222', 'aa@jbbank.com'])
# ws.append([ 203 ,'박성실', '데이터분석부', '010-5678-3333', 'aa@jbbank.com'])
# ws.append([ 204 ,'박요온', '데이터분석부', '010-5678-4444', 'aa@jbbank.com'])
#
#
# wb.save(excel_file)


#엑셀파일불러오기
excel_file = './data/임직원.xlsx'

wb = openpyxl.load_workbook(excel_file)
ws = wb.active





key_list = []
val = []
#
# for j in range(1,5):
#     value_list = []
#     for i in range(1,6):
#         #key = ws.cell(column=i, row=1).value
#         #key_list.append(key)
#
#         value = ws.cell(column=i, row=j).value  #값 하나씩 가져옴.
#         value_list.append(value) #한줄불러옴.
#
#     val.append(value_list)  #모든 값 가져옴
#
#
# for i in range(1,4):
#     dict = {}
#     for j in range(4):
#         dict[val[0][j]] = val[i][j]
#     print(dict)


for j in range(1,6):
    for i in range(1,6):
        value = ws.cell(column=i, row=j).value
        print(value,end= '\t')
    print()

wb.close()



#다른방법
arr_row = list()
rows = ws.rows
for row in rows:
    arr_row.append(row)
    for cell in row:
        val = cell.value
        print(val, end='\t')
    print()