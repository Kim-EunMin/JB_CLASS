import openpyxl


excel_file = 'data/JPEG_임직원.xlsx'


wb = openpyxl.load_workbook(excel_file)  #기존에 있던 excel 가져온다.

ws = wb["전북은행"]  #전북은행시트 가져온다.

#데이터 수정하기
ws['C7'] = '빅파이크래프트'
ws['D7'] = '010-5670-3847'
ws['E7'] = 'bigpycraft@gmail.com'



wb.save(excel_file)

