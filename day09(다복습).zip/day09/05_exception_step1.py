import traceback

#처음에 보았던 트레이스백 메시지와 함꼐 나타낸 함수

def exception_test4():
    print("[1] can you add 2 and '2' in python?\n\n")

    try:
        print(2+'2')

    except TypeError:
        print('Type Error!')
        traceback.print_exc()  #트레이스백 메세지 출력

    print("It's not possible to add integer and string together.")

exception_test4()