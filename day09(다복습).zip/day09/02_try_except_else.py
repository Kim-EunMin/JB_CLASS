try:
    print('안녕하세요')
    #print(param)
except:
    print('예외가 발생했습니다')

else:    #try문이 정상적으로 수행됐을때 찍힌다.
    print('예외가 발생하지 않았습니다.')