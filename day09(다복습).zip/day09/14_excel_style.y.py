import openpyxl
from openpyxl.styles import PatternFill, colors, Font, Alignment

excel_file = './data/임직원.xlsx'

wb = openpyxl.load_workbook(excel_file)
ws = wb.active


#배경 색상 지정
pattern_red = PatternFill(start_color='FF0000',    fill_type="solid")
pattern_yellow = PatternFill(start_color='FFFF00', fill_type="solid")
pattern_blue = PatternFill(start_color=colors.BLUE ,fill_type="solid")

ws.cell(1,2).fill = pattern_red      #row,col




#폰트
font_20 = Font(name='나눔고딕', size=20, color=colors.BLUE)
ws.cell(1,1).font = font_20



#정렬
align_center = Alignment(horizontal='center', vertical='center')
for idx in range(1,6):
    ws.cell(1,idx).alignment = align_center


for idx in range(1,7):
    ws.cell(idx,2).alignment = align_center


#셀크기
ws.row_dimensions[1].height = 20
ws.column_dimensions['C'].width = 50
ws.column_dimensions['D'].width = 50
ws.column_dimensions['E'].width = 50






wb.save(excel_file)