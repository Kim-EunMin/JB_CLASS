try:
    print("안녕하세요")
    print(param)
except:
    print('예외가 발생했습니다!')
finally:   #에러발생하든 안하든 그냥 무조건 실행됨 -> DB connection 같이 open 한 것들을 close 할 수 있게 사용하면 좋음
    print("무조건 실행하는 코드")



#except : 문제발생시 로그체크하는게 많이 나옴 (로그파일에 저장)
#finally : 마무리 작업을 많이 넣는다.
