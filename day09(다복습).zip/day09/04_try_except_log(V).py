from datetime import datetime

module_name = 'FileName'  #이런거 써놓으면 오류나서 로그 볼때 편하다.


def exception_test2():
    method_name = "exception_test2()"    #이런거 써놓으면 오류나서 로그볼때 편하다.
    print("[1] can you add 2 and '2' in python?\n\n")

    try:
        print('[2] try it ', 2+ '2')  # type error 발생

    except Exception as err:
        # print('[E1]',err.__str__())
        # print('[E2]',err.__class__)
        # print('*'*100)

        cur_time =  datetime.now()
        log_time = '[{}]'.format(str(cur_time)[:19])


        err_msg = '\n{} {}.{} 에러발생 \n{} :: {}'.format(
                      log_time, module_name,method_name, err.__class__, err
        )

        print('log 파일에 저장되는 부분 : {}'.format(err_msg))



exception_test2()

#이런건 utill.py 에 만들어서 저장해놓고 불러서 쓰는것도 좋다.


