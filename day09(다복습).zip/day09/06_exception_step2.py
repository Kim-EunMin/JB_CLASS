#예외 처리 방식에서의 else , finally 옵션 구문 활용


def exception_test5(file_path):
    try:
        f = open(file_path,'r')   #파일열기시도 -> 에러발생함

    except IOError:
        print('cannot open', file_path)  #에러메시지 출력

    else:
        print('File has', len(f.readlines()), 'lines')  #파일라인수출력
        f.close()     #파일닫기

    finally:
        #예외 발생 상관없이 무조건 실행
        print('I just tried to read this file.', file_path)

