import openpyxl

excel_file = 'data/JPEG_임직원.xlsx'


wb = openpyxl.load_workbook(excel_file)         #load_workbokk> 읽는걸 가져옴

ws = wb.active

#데이터추가1
ws['A1'] = '사번'
ws['B1'] = '이름'
ws['C1'] = '부서명'
ws['D1'] = '연락처'
ws['E1'] = '이메일'


# 데이터 추가2
ws.cell(row=2, column=1, value=101)
ws.cell(row=2, column=2, value='김은민')
ws.cell(row=2, column=3, value = '영업기획부')
ws.cell(row=2,column=4, value='010-1234-1111')
ws.cell(row=2,column=5, value='aa@kjbank.com')


#전북은행시트만들기

#데이터추가3  (리스트 값으로 해도 값이 순차적으로 다 들어가진다)
ws.append([ 201 ,'한혜형', '디지털영업팀', '010-5678-1111', 'aa@jbbank.com'])
ws.append([ 202 ,'김영목', '카드사업부', '010-5678-2222', 'aa@jbbank.com'])
ws.append([ 203 ,'박성실', '데이터분석부', '010-5678-3333', 'aa@jbbank.com'])
ws.append([ 204 ,'박요온', '데이터분석부', '010-5678-4444', 'aa@jbbank.com'])
ws.append([ 205 ,'오승현', '지주', '010-5678-5555', 'aa@jbbank.com'])
ws.append([ 206 ,'김진수', '전략기획본부', '010-5678-6666', 'aa@jbbank.com'])



wb.save(excel_file)

