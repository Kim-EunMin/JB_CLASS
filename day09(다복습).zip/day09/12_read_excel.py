import openpyxl

excel_file = './data/JPEG_임직원.xlsx'

wb = openpyxl.load_workbook(excel_file)
ws = wb.active



#데이터조회
A1 = ws['A1'].value
print(" A1 = {} ".format(A1))

B1 = ws.cell(column = 2, row=1)
print(" B1 = {} ".format(B1))


wb.close()

