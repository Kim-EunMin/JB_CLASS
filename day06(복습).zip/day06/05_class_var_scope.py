#클래스 변수와 인스턴스 변수
# 변수의 선언위치에 따라 달라지는 유효범위

class MyChildren:
    school = '대학교'  #클래스변수 country 선언 ( init 안에서 하는거아니고 그냥 바로하는걸 클래스변수라고함)
                       #(클래스변수: 디폴트로 받아주는거)

    #초기화함수 재정의
    def __init__(self,name):  #init 안에 넣어두는 것 같은걸 -> 인스턴스변수
        self.name = name #인스턴스변수 name 생성



        #mychild -> 초기화값인 대학교 그대로 가져옴.




    #동일하게 나옴 -> 클래스변수는 다 동일한 메모리 위치를 가지고 있음
        # 마음이가 구르기에 추가하고 dog2 가 또 2개를 추가하기때문에
         # 결과값이 똑같게 나옴.




#인스턴스 변수(인스턴스간 공유 안됨)
class Cat:
    def __init__(self,name):
        self.name = name
        self.tricks = [] #인스턴스 변수 선언
        # cat -> 인스턴스 변수 -> init 안에 tricks 를 만듬 (인스턴스변수선언)

    def add_trick(self,trick): #여기서 trick 은 변수
        self.tricks.append(trick) #인스턴스 변수에 값 추가

cat1 = Cat("하늘이")   # 각 객체별로 값을 독립적으로 가짐.
cat2 = Cat('야옹이')





cat1.add_trick('구르기')
cat2.add_trick('두발로 서기')
cat2.add_trick('죽은척 하기')

print(cat1.name, ':', cat1.tricks)  #위에서 self.tricks 를 말하는듯
print(cat2.name, ':', cat2.tricks)  # 각 객체별로 값을 독립적으로 가짐




#객체지향 ;

#물화책