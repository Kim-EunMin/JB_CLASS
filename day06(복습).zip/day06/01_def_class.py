# 클래스 정의 : X

class MyClass:
    name = '찬영'      #이름이란 속성

    def sayHello(self): #클래스 내부에서 함수를 구현할때 self 를 꼭 써주자.
        hello = "Hello, " + self.name + '\t a Good day!'
        return hello

    def addAge(self):
        return self.age + 1

myClass = MyClass()     #name, sayHello, addAge 가 메모리상에 올라가게끔 저장이 된다.
obj_name = myClass.name
obj_method = myClass.sayHello()

print(obj_name)
print(obj_method)





