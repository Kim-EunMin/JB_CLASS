#사용자가 정보를 입력한다.

i = input('책의 정가는 ?')
price = int(i)

i = input('발행 부수는 ?')
sales = int(i)

i = input('인세율(퍼센트)은 ?')
per = float(i)


def calc_royalty(price, sales, per):
    result = price * sales * (100-per) / 100
    result = int(result)
    return result



v = calc_royalty(price, sales, per)
print('인세는 ',v,'원입니다.')

