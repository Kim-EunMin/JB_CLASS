num1 = 10
num2 = -20


print('abs() :', abs(num1))
print('abs() :', abs(num2))
print('pow() :', pow(num1, 2))


numbers = [2,4,6,-3,55,33]
print('min :', min(numbers))
print('max :', max(numbers))
print('-'*30)

numbers = [1,2,3,4,5]
print('sum :', sum(numbers))
print('eln :', len(numbers))
print('average :', sum(numbers)/len(numbers))