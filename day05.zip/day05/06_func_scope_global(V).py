#지역변수와 전역변수
param = 10
strdata = '전역변수'

def func1():
    strdata = '지역변수'
    print('func1.strdata = %s, id = %d' % (strdata, id(strdata)))



func1()   #함수안에 선언되어있음
print('main1.strdata = %s, id = %d' % (strdata, id(strdata)))  #밖에 선언되어있음
#strdata 로 이름이 같지만 id 는 다르게 나온다.


def func2(param):
    param = 20
    print('func2.param = %d, id = %d' % (param, id(param)))

func2(param)
print('main2.param = %d, id = %d' %(param, id(param)))



def func3():
    global param  #전역변수화시킨다. ( 프로그램어디서든 동일하게 적용)
    param = 30
    print('func3.param = %d, id=%d' % (param, id(param)))
    #함수안에서 전역변수화 되어서 바깥에서도 똑같이 적용됨



func3()
print('main3.param = %d, id= %d' % (param, id(param)))


#다른쪽에서도 적용시키고 싶으면 global 사용하면 됨



#https://blockdmask.tistory.com/565