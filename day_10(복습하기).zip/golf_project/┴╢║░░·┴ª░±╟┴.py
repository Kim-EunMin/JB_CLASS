import openpyxl
from openpyxl.styles import PatternFill, colors, Font, Alignment

excel_file = "golf_score_board.xlsx"
wb = openpyxl.load_workbook(excel_file)
ws = wb['스코어']



# 미션1 : 참가선수들 등록 (실시간입력/등록명단파일호출)
#
# file = open("명단.txt", "r",encoding = 'utf-8')
# line = file.readlines()  #한줄씩읽어온다.
# file.close()
#
# peoples  = []        #참가선수리스트
# for idx in range(len(line)):
#     people = line[idx].replace('\n','')  #참가선수1명씩 가져옴.
#     peoples.append(people)
# print(peoples)
#
# def mp(a):
#     for idx in range(0,len(a)):
#         b = ws.cell(row=idx+3,column=1,value=a[idx])
#     print(b)
# mp(peoples)



def mp2(filename):
    #step1   :  file 불러오기
    file = open("{}".format(filename), "r",encoding = 'utf-8')
    line = file.readlines()
    file.close()

    #step2 : 참가선수를 리스트형태로 변환
    peoples  = []
    for idx in range(len(line)):
        people = line[idx].replace('\n','')  #참가선수1명씩 가져옴.
        peoples.append(people)               #전체참가선수를 리스트형태로 저장

    for idx in range(0,len(peoples)):                 #엑셀에 참가선수 뿌리기
        b = ws.cell(row=idx+3,column=1,value=peoples[idx])
        print(b.value)

    print('참가선수 등록 완료')

mp2("명단.txt")



# 미션2 : 참가선수들 HOLE별 스코어를 랜덤하게 입력 (-2 ~ PAR*2)
# 0. 셀별 PAR 정하기
# PAR3 : H3,H8,H11,H14
# PAR5 : H4,H6,H10,H17
# ELSE
# 난수뽑기 self.computer = randint(0, 2)

# 미션3 : 18홀까지의 스코어, 보정치를 계산하여 등록 (핸디는 옵션), 보정치는 없다.

# 미션4 : 보정치 기준으로 랭킹 등록, 각종 기록 갯수 등록

# 미션5 : 대회결과 시트에 결과에 맞는 선수명과 최종성적/기록수를 등록

wb.save(excel_file)
print('프로그램 종료')
