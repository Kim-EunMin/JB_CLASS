import logging
import test_lib  #test_lib.py 를 미리 만들어둬야함



logging.basicConfig(filename = 'log/test_mode.log',level=logging.DEBUG, encoding='utf-8')

def main():
    logging.info('메인함수 시작')
    test_lib.do_something()

    logging.info('메인함수 종료')

if __name__ == '__main__':
    main()

    