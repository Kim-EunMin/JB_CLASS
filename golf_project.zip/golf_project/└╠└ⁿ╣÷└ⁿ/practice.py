


rank_dict = {}  # { 100점 : 1등, 90점 : 2등 ... } 로 구성된 딕셔너리
rank = 1  # 1등부터 시작
sort_score = [68,68,68,69,70,70,71,79,80,81]
for i in range(len(sort_score)):
    rank_dict[sort_score[i]] = rank  # 점수별로 등수 매겨준다.
    if sort_score[i] == sort_score[i - 1]:  # 동점이라면?
        rank_dict[sort_score[i]] = rank - sort_score.count(sort_score[i]) + 1  # (예 : 90,90,80,79,60 -> 1,1,3,4,5 로 등수 나옴 )
    else:
        pass

    rank += 1


print('선수점수정렬 :', sort_score )
print('등수만들기   :', rank_dict )


