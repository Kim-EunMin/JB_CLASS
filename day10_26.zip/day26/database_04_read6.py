from day26.database_04_read1 import getBooksDF
from day26.database import common as dbcomm
import pandas as pd

# 쪽수 많은 책 조회용 함수
def find_big_books(db_name):
    ret_df = pd.DataFrame()
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        # 조건걸기
        db_sql = "SELECT * FROM book_mgr"
        db_sql += " WHERE pages>550 "

        cur.execute(db_sql)

        print('[4] 페이지 많은 책 출력하기')
        books = cur.fetchall()
        ret_df = getBooksDF(books)

    except:
        is_success = False
        print('Database Error')

    finally:
        conn.close()

    return is_success, ret_df



if __name__ == '__main__':
    db_name = 'bpcdb'
    is_success, books_df = find_big_books(db_name)

    if is_success:
        print('조건에 맞는 데이터는 총 %d 건입니다' % len(books_df))
        print(books_df)
    else:
        print('데이터를 조회하지 못했습니다')

