from day26.database_04_read1 import getBooksDF
from day26.database import common as dbcomm
import pandas as pd

#1개 조회용 함수
def select_one_book(db_name):
    is_success = True
    ret_df = pd.DataFrame()

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        # 조회용 sql 실행
        db_sql = 'SELECT * FROM my_books'
        cur.execute(db_sql)

        print('[3] 1개 데이터 출력하기')
        book = cur.fetchone()
        books = [book]
        ret_df = getBooksDF(books)

    except:
        is_success = False

    finally:
        conn.close()

    return is_success, ret_df


if __name__ == '__main__':
    db_name = 'bpcdb'
    is_success, books_df = select_one_book(db_name)

    if is_success:
        print('하나의 데이터를 성공적으로 조회하였습니다')
        print(books_df)
    else:
        print('데이터를 조회하지 못했습니다')


