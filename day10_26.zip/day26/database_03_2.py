# 방법2  ( 방법1보다 좀더 효율적임)


from day26.database import common as dbcomm

def insert_books(db_name, book_info):
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        db_sql = 'INSERT INTO book_mgr VALUES (%s, %s, %s, %s, %s)'
        cur.execute(db_sql, book_info)
        #cur.execute(db_sql, ('인더스트리 4.0', '2016.07.09' , 'B', 584, 1))
        # book_info = ('인더스트리 4.0', '2016.07.09', 'B', 584, 1)
        # book_info = ('인더스트리 2.0', '2016.07.09', 'B', 584, 1)
    except:
        is_success = False
        print('database Error!')

    finally:
        if is_success:
            conn.commit()
        else:
            conn.rollback()
    return is_success


if __name__ == '__main__':
    db_name = 'bpcdb'
    book_info = ('인더스트리 4.0', '2016.07.09', 'B', 584, 1)
    is_success = insert_books(db_name, book_info)

    if is_success:
        print("데이터 성공적으로 등록됨")
    else:
        print('데이터 등록 실패')

