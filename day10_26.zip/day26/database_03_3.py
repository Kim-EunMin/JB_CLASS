# 방법3


from day26.database import common as dbcomm

def insert_books(db_name, arr_book_info):
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        db_sql = 'INSERT INTO book_mgr VALUES (%s, %s, %s, %s, %s)'
        cur.executemany(db_sql, arr_book_info)

    except:
        is_success = False
        print('database Error!')

    finally:
        if is_success:
            conn.commit()
        else:
            conn.rollback()
    return is_success


if __name__ == '__main__':
    db_name = 'bpcdb'
    arr_book_info = [('인더스트리 4.0', '2016.07.09', 'B', 584, 1),
                     ('빅데이터 마케팅' , '2012.08.25', 'A', 296,1),
                     ('사물인터넷 전망' , '2013.08.22', 'B', 526,0)]
    is_success = insert_books(db_name, arr_book_info)

    if is_success:
        print("데이터 성공적으로 등록됨")
    else:
        print('데이터 등록 실패')
