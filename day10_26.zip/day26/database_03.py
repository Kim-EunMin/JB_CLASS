# data insert 하는 함수 1

from day26.database import common as dbcomm

def insert_books(db_name, db_sql):
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        cur.execute(db_sql)
    except:
        is_success = False
        print('database Error!')

    finally:
        if is_success:
            conn.commit()
        else:
            conn.rollback()
    return is_success



if __name__ == '__main__':
    db_name = 'bpcdb'
    db_sql = "Insert into book_mgr VALUES ('메가트랜드','2002.03.02','A',200,0)"
    is_success = insert_books(db_name, db_sql)

    if is_success:
        print("데이터 성공적으로 등록됨")
    else:
        print('데이터 등록 실패')
        
        
        
        #방법1 : db_sql 이라고 하드코딩하는방법