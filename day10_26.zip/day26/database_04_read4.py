from day26.database_04_read1 import getBooksDF
from day26.database import common as dbcomm
import pandas as pd

def select_some_books(db_name, number):
    is_success = True
    ret_df = pd.DataFrame()

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        # 조회용 sql 실행
        db_sql = 'SELECT * FROM my_books'
        cur.execute(db_sql)

        # 조회한 데이터불러오기
        print('[2] 데이터 일부 출력하기')
        books = cur.fetchmany(number)

        ret_df = getBooksDF(books)

    except:
        is_success = False
        print('Database error')

    finally:
        conn.close()

    return is_success, ret_df



if __name__ == '__main__':
    db_name = 'bpcdb'
    is_success, books_df = select_some_books(db_name, 2)

    if is_success:
        print('조회환 데이터는 총 %d 건 입니다' % len(books_df))
        print(books_df)
    else:
        print('데이터를 조회하지 못했습니다')
