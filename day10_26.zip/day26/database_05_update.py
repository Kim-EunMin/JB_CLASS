from day26.database_04_read1 import getBooksDF
from day26.database import common as dbcomm
from database_04_read5 import select_one_book
import pandas as pd


def update_books(Db_name):
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur = conn.cursor()

        db_sql = 'UPDATE book_mgr SET recommendation=%s where title =%s '

        cur.execute(db_sql, (1,'메가트렌드'))

    except:
        is_success = False
        print('Database Error')

    finally:
        if is_success:
            conn.commit()
        else:
            conn.rollback()
        conn.close()

    return is_success



if __name__ =='__main__':
    db_name = 'bpcdb'
    is_success, books_df1 = select_one_book(db_name)

    if update_books(db_name):
        print("데이터 수정됨")
    else:
        print('데이터 수정안됨')

    is_success, books_df2 = select_one_book(db_name)

    books_df = pd.concat([books_df1, books_df2], axis=0)
    books_df['update'] = ['수정전','수정후']
    books_df.set_index('update', inplace=True)
    print(books_df)