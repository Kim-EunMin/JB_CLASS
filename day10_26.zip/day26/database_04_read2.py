from day26.database import common as dbcomm


# 튜플형태로 호출이된다.
def select_all_books(db_name):
    is_success = True

    try:
        conn = dbcomm.get_connection(db_name)
        cur  = conn.cursor()

        #조회용 sql 실행
        db_sql = 'SELECT * FROM my_books'
        cur.execute(db_sql)

        #조회한 데이터불러오기
        print('[1] 전체 데이터 출력하기')
        books = cur.fetchall()

    except:
        is_success = False
        print('Database error')

    finally:
        conn.close()

    return is_success, books


if __name__ == '__main__':

    db_name = 'bpcdb'

    is_success, books = select_all_books(db_name)

    if is_success:
        print('조회환 데이터는 총 %d 건 입니다' % len(books))
        print(books)
    else:
        print('데이터를 조회하지 못했습니다')
