#test_lib.py

import logging

def do_something():
    logging.info('Doing something')
    print('check')

if __name__ == '__main__':
    do_something()