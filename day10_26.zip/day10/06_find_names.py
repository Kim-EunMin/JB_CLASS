import re
#0-9 대신 \d 라고 써도 됨
#\s -> space

text = """
옛날 옛적에 김진수라는 사람이 살았습니다.
그에게는 5형제가 있었는데, 김진수, 김진구, 김진용, 김진태, 김진욱, 김진 이렇게 다섯명 있었습니다.
그리고 그는 결혼을 해서 김찬영, 김준영, 김채영 3남매를 낳고 알콩달콩 행복하게 잘 살았습니다.
채영이가 좋아하는 사촌은 김예영이랑 김민영이랍니다. 김서영이는 본지가 너무 오래되었네요.
"""


pattern = re.compile("김진\w") #김진 2글자돌림임
                           #앞에 김진은 무조건들어가고 뒤에문자붙어있어야함. (스페이스는 안됨)
                           # '김진' 은 안나옴.
bother  = pattern.findall(text)
print(bother)

bother = sorted(set(bother))
print(bother)    #중복제거



pattern2 = re.compile('김\w영')
children = pattern2.findall(text)
print(children)



