data = 10,20;
x=10;y=20
#print(data[0])

def get_area(w,h):
    return w,h


print(get_area(data))
print(get_area(*data))
print(get_area(x,y))
print(get_area(y,x))

#3 4 1 2 4 1 3 1 4 2