import re

#테스트용 문자열 저장
text = 'My id number is [G203_5A]'
print('#테스트 문자열 : %s \n%s' % (text, '-'*50))



result = re.findall('[a-z]', text)  #a 부터 z (소문자찾기)
print(result)


result = re.findall('[a-z]+', text)  #a 부터 z
print(result)
 #+ 하면 연관된건 다 붙여서 나온다. (연속해서 찾아온다.)



result = re.findall('[a-zA-Z0-9]+', text)
print(result)     #a부터z 랑 A부텈Z  0~9가져오되 붙여서 가져옴.



result = re.findall('[^a-zA-Z0-9]+', text)
#a부터 z , A부터 Z 0~9 제외하고 가져오고싶다 .(^ 표시이용하기 ) ->예: 특수문자같은걸 가져올 수 있다.
print(result)


result = re.findall('[\w]', text)  #영문자,숫자, 언더바 -> 한글자씩 가져옴
print(result)




result = re.findall('[\W]', text)  #w가 지정하는 이외의 단어들 -
print(result)                      #영문자 및 숫자 및 '_' 기호 제외하고 가져온다.)





