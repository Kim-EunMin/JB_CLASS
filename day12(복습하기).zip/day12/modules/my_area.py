# File name: my_area.py      (모듈폴더안에 my_area 를 만든다. )

PI = 3.14

def square_area(a): # 정사각형의 넓이 반환
    return a ** 2

def circle_area(r): # 원의 넓이 반환
    return PI * r ** 2
