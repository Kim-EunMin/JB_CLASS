# File name: my_module2.py

def func2():
    print("func2 in  my_module2 ")

def func3():
    print("func3 in  my_module2 ")
