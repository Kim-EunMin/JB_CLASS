#Keyword Arguments, 키워드 인자 활용하기

def MyCar(brand, seats=4, type='세단'):
    print('나의 차는 {b} {s}인승 {t}이다.'.format(
          b = brand,
          s = seats,
          t = type
    ))


#위치 인자 값 1개 ( 맨처음나오는 건 brand 값이다.)
MyCar('아우디')

#키워드 인자 값 1개 (위치말고 키워드로 지정해서 호출)
MyCar(brand = '렉서스')

#위치인자 값 1개, 키워드인자값1개 (혼용으로 사용가능)
MyCar('제규어',seats = 3)

#키워드 인자 값 2개
MyCar(brand ='머큐리', type = '머슬카')

#키워드 인자 값 순서바꿔도 된다.( 순서바꿀땐 키워드인자필수)
MyCar(type = '미니벤', brand = '카니발')


#순서지킬 경우 (키워드 인자안써도됨)
MyCar('카니발',9,'미니벤')

#순서안지킬땐 (키워드 인자값 필수)
MyCar('쉐보레', type = 'SUV', seats= 9)