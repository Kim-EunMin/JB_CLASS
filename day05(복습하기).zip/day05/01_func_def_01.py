#예제1
def add_txt(arg1, arg2):
    print(arg1, arg2)

param1 = '대~한민국~'
param2 = '짝짝~짝~ 짝.짝!!'

add_txt(param1, param2)

#예제2
def add_num(num1, num2):
    result = num1 + num2
    return result

param1 = 40
param2 = 50

sum = add_num(40,50)

print('%d와 %d의 합은 %d입니다.' % (param1, param2, sum))



#예제3
def exchangeUSDtoKRW(dollar):
    won = dollar * 1065
    return won

krw =exchangeUSDtoKRW(2000)
print('환전한 금액은 %d 원 입니다.'%(krw))


#krw = exchangeUSDtoKRW()
#print('환전한 금액은 %d 원 입니다.'%(krw))  -> type 에러 발생







def add2(a,b, c=0):
    result = a+b+c
    return result
print(add2(1,2))




def add3(nums):
    result = 0
    for num in nums:
        result += num

    return result
print(add3([1,2,3]))




#가장효율적인 방법이다.
def add4(*nums):
    result = 0
    for i in nums:
        result += i
    return result
print(add4(1,2,3,4))



