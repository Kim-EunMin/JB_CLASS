def calculator(type, num1=0, num2=0):
    result=0
    if type == '+':
        result = sum(num1,num2)
    elif type == '-':
        result = num1-num2
    elif type in ('*', 'x','X'):
        result = num1*num2
    elif type == '/':
        result = num1/num2
    else:
        print('잘못된 기호입니다')
        result = 'Error'
    return result


def sum(num1, num2):
    return num1 + num2


result = calculator('+',9,8)
print(result)