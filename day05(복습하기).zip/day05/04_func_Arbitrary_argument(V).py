#Arbitrary Arguments, 가변인자리스트활용


def introduceMyFamily(my_name , *family_names, **family_info):
    print('안녕하세요, 저는 {} 입니다'.format(my_name))
    print('-'*50)
    print('제 가족들의 이름은 아래와 같아요.')

    for name in family_names:
        print('* {}'.format(name), end = '\t')
    else:   #for-else문
        print('(참고 에러없음)')
    print('-'*50)

    for key in family_info.keys():  #주소, 가훈, 소망 key에 담김
        print('- %s : %s' % (key, family_info[key]))





introduceMyFamily('진수','희영','찬영','준영','채영',
                  주소='롯데캐슬',가훈='극기상진',소망='세계일주')






