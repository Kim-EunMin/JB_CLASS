def suqare(num):
    return num**2
print(suqare(2))


#간단한 함수는 안만들고 람다로 가능
print( (lambda num : num**2)(3) )  



res= 5 + (lambda x: x**2) (3)   #수식안에 써도 됨
print(res)


func1 = (lambda x: x**2)       #함수로 만들어 둔 후에 값을 넣는 것도 가능
print(type(func1),func1(2))



