def get_area(a,b):
    return a+b

data = (10,20)  #tuple
#print(get_area(data))  data를 하나의 값으로 인식하기때문에 인자가 부족하다고 에러뜸


print(get_area(*data))    #* 을 붙여주면 -> 알아서 풀어져서 각각 호출이 된다.




def introduce(name, greeting):
    return '{name}님, {greeting}'.format(
        name = name,
        greeting= greeting,
    )

introduce_dict = {
    'name' : '김은민',
    'greeting' : 'hello',
}


print(introduce(**introduce_dict))
# =>  fair 니까 별이 2개 붙음




