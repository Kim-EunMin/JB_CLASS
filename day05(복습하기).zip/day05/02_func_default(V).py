def orderMenu(menu):
    print('손님, %s 를 주문하셨습니다.' % (menu))

#orderMenu()
# -> typeerror 발생  -> menu 값으로 무조건 1개가 들어가야한다.



#Default Argument
def orderCoffee(menu = '카페라떼'):  #디폴트로 카페라뗴를 설정해주었다.
    print('손님, %s 를 주문하셨습니다.' % (menu))

orderCoffee()  #디폴트값이 있기때문에 에러가 발생하지않는다.
orderCoffee('아이스티')




