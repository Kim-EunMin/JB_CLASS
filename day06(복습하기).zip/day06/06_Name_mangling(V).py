#이름장식

class MyCountry:
    country = 'Korea'
    __city    = 'seoul'


result = dir(MyCountry)  #모든 속성값들을 출력되게끔함 (내장함수, 내장변수들이 나옴)
print(result)   #dir 해보면 city, country 가 출력된다.
                #city 앞에 __하면 city는 안나온다. (다이렉트로 노출 안시킴)
                # 즉 , __가 있는 것에 한하여 이름을 변경해 버리는 기법
                # 보안성기능에선 쓸 만 함




num =0
for internal_element in result:
    num+= 1
    print(num, internal_element)

