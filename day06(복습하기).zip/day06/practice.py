#멤버변수
#
# class Unit:
#     def __init__(self, name, hp,damage):
#         self.name = name   # 멤버변수 -> 클래스내 정의된 변수
#         self.hp = hp
#         self.damage = damage
#
#         print("{0} 유닛이 생성 되었습니다.".format(self.name))
#         print('체력 {0}, 공격력 {1}'.format(self.hp, self.damage))
#
# #레이스 :
#
# wraith1 = Unit('레이스',820,5)
#
#
# #외부에서 멤버변수를 써보자.
# print('유닛이름 : {0}, 공격력 : {1}'.format(wraith1.name, wraith1.hp))  #.을 찍으면 멤버변수에 접근가능
#
#
#
# # 마인드 컨트롤 : 상대방 유닛을 뺏음.
# wraith2 = Unit('뺴앗은레이스',80,5)
# wraith2.clocking  = True  #clocking 기능있다.          #클로킹이란 변수는 __init__안에 없다. -> 외부에서 클로킹변수를 추가로 할당을 해서 True 라는 값을 넣었다.
#                                                      # --> 이런식으로, 어떤 객체에 추가로 외부에서 변수만들어서 쓸 수 있다.
#                                                       #->wriath2 에는 clocking 변수있는데 wraith1 에는 clocking 변수없다.
#
# if wraith2.clocking == True:
#     #print("{0} 는 현재 클로킹 상태입니다.".format(wraith2.name))



#
#
#
#
# class Unit:
#     def __init__(self, name, hp,damage):
#         self.name = name   # 멤버변수 -> 클래스내 정의된 변수
#         self.hp = hp
#         self.damage = damage
#
#         print("{0} 유닛이 생성 되었습니다.".format(self.name))
#         print('체력 {0}, 공격력 {1}'.format(self.hp, self.damage))
# #
#
# class AttackUnit:
#     def __init__(self, name, hp, damage):
#         self.name = name  # 멤버변수 -> 클래스내 정의된 변수
#         self.hp = hp
#         self.damage = damage
#     #함수하나 더 만든다.(AttackUnit에 포함된것)
#     def attack(self,location):
#         print('{0} : {1} 방향으로 적군을 공격합니다. [공격력  {2}]'.format(self.name,  #위에서 정의된 name 과 damage쓴다.
#                                                                      location,  #전달받은 값을 쓴다.
#                                                                     self.damage
#                                                                      ))
#
#     def damaged(self, damage):
#         print('{0} : {1} 데미지를 잃었습니다.'.format(self.name, damage))
#         self.hp -= damage
#         print('{0} : 현재 체력은 {1}입니다.'.format(self.name, self.hp))
#         if self.hp <= 0:
#             print('{0} : 파괴되었습니다.'.format(self.name))
#
# #
# firebat1 = AttackUnit('파이어뱃',50,16)
# firebat1.attack('5시')  #def attack 보면 location 만 적으면 된다.
#
# firebat1.damaged(25) #25공격받았다고 가정
# firebat1.damaged(25)  #2번받았다
#








# # 다중상속
# # 부모클래스 2개 이상 상속받는다.
# # Unit 과 같은것이 부모클래스 #attackUnit 이 자식클래스
# #다중상속-> 부모가 둘 이상
#
# # 일반유닛
# class Unit:
#     def __init__(self, name, hp):
#         self.name = name
#         self.hp = hp
#
#
#
# #공격유닛
# class AttackUnit(Unit):
#     def __init__(self, name, hp, damage):
#         Unit.__init__(self,name,hp)
#         self.damage = damage
#
#     def attack(self,location):
#         print('{0} : {1} 방향으로 적군을 공격합니다. [공격력  {2}]'.format(self.name,
#                                                                      location,
#                                                                     self.damage
#                                                                      ))
#
#     def damaged(self, damage):
#         print('{0} : {1} 데미지를 잃었습니다.'.format(self.name, damage))
#         self.hp -= damage
#         print('{0} : 현재 체력은 {1}입니다.'.format(self.name, self.hp))
#         if self.hp <= 0:
#             print('{0} : 파괴되었습니다.'.format(self.name))
#
# #날수있는기능
# class Flyable:
#     def __init__(self, flying_speed):
#         self.flying_speed = flying_speed
#
#     def fly(self,name,location):
#         print("{0} : {1} 방향으로 날아갑니다. [속도 : {2}]".format(name, location, self.flying_speed))
#
# #공중공격유닛클래스
# class FlyableAttackUnit(AttackUnit,Flyable): #1. 다중상속 받으려면 콤마쓰면됨. -> AttackUnit 에서쓰는것,Flyable에서 쓰는 것 전부 ㅆ가져와서 쓸 수 있다.
#     def __init__(self, name, hp, damage, flying_speed):
#         AttackUnit.__init__(self,name,hp,damage)
#         Flyable.__init__(self, flying_speed)
#
#
# #드랍쉽: 공격유닛이나, 수송하는 기능 공격기능은 없음.
# #발키리 : 공중 공격유닛
# valkyrie = FlyableAttackUnit('발키리',200,6,5)
# valkyrie.fly(valkyrie.name, '3시')  #Flyable클래스안에 fly 함수를 호출  (이름과 위치를 호출해주면 됨)





#메소드 오버라이딩
#-> 부모클래스에서 정의한 메소드 말고 자식클래스에서 정의한 메소드 사용하고싶을때


class Unit:
    def __init__(self, name, hp, speed):
        self.name = name   # 멤버변수 -> 클래스내 정의된 변수
        self.hp = hp
        self.speed = speed

    def move(self, location):
        print('지상유닛 이동')
        print('{0} : {1} 방향으로이동합니다, [속도 : {2}'.format(self.name, location, self.speed))

class AttackUnit(Unit):
    def __init__(self, name, hp, damage,speed):            #Unit 에서 speed 추가 되었으니 Attack.Unit도 수정해주기
        Unit.__init__(self,name,hp,speed)
        self.damage = damage

    def attack(self,location):
        print('{0} : {1} 방향으로 적군을 공격합니다. [공격력  {2}]'.format(self.name,
                                                                     location,
                                                                    self.damage
                                                                     ))

    def damaged(self, damage):
        print('{0} : {1} 데미지를 잃었습니다.'.format(self.name, damage))
        self.hp -= damage
        print('{0} : 현재 체력은 {1}입니다.'.format(self.name, self.hp))
        if self.hp <= 0:
            print('{0} : 파괴되었습니다.'.format(self.name))

#날수있는기능
class Flyable:
    def __init__(self, flying_speed):
        self.flying_speed = flying_speed

    def fly(self,name,location):
        print("{0} : {1} 방향으로 날아갑니다. [속도 : {2}]".format(name, location, self.flying_speed))

#공중공격유닛클래스
class FlyableAttackUnit(AttackUnit,Flyable): #1. 다중상속 받으려면 콤마쓰면됨. -> AttackUnit 에서쓰는것,Flyable에서 쓰는 것 전부 ㅆ가져와서 쓸 수 있다.
    def __init__(self, name, hp, damage, flying_speed):
        AttackUnit.__init__(self,name,hp,0, damage)  #speed 굳이 필요없어서 0으로 처리함.
        Flyable.__init__(self, flying_speed)
    def move(self,location):  #1. move 함수정의
        print('공중유닛이동')
        self.fly(self.name, location)

vulture = AttackUnit('벌쳐',80,10,20)

battlecruiser = FlyableAttackUnit("배틀크루져", 500,25,3)

vulture.move('11시')
battlecruiser.fly(battlecruiser.name, '9시')


#어떨땐 move 함수 어떨땐 fly 함수를 써야해서 너무 귀찮다.
# move 함수만 쓰면 편할텐데!!
# 1. FlyableAttackUnit 안에 move 함수 만든다.
# #똑같은 move 함수를 재정의했음. # 만약 move 함수 ㅗ출하면 Unit의 move가 호출되는게 아니라 FlyableAttackUnit안의 move 함수를 호출한다.
battlecruiser.move('9시')  #location만 하면된다