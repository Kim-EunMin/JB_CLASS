#정보은닉 data hiding

class MyFavorite:
    __hobby = '야구'
    __drink = '맥주'   #속성값들은 오픈시키고 싶지 않을때

    def get_hobby(self):
        return self.__hobby

    def get_drink(self):
        return self.__drink  #drink 정보를 읽어서 리턴해준다.
    
    def set_hobby(self, hobby):  #hobby 랑 drink 값을 업데이트쳐주는 느낌이라고생각하자.
        self.__hobby = hobby

    def set_drink(self,drink):
        self.__drink = drink

myInfo = MyFavorite()  #객체를 만들어서 이름을 myInfo 라 함
my_hobby = myInfo.get_hobby()
my_drink = myInfo.get_drink()
print(my_hobby, my_drink)


# myInfo.__hobby = '골프'
# myInfo.__drink = '소주'
myInfo.set_hobby('골프')  #값을 골프, 소주로 바꾸려면 __hobby 로 하면 안되고 set_hobby를 써야함
myInfo.set_drink('소주')
my_hobby = myInfo.get_hobby()
my_drink = myInfo.get_drink()

#myInfo. 점찍었을때 hobby 랑 drink 가 안보임