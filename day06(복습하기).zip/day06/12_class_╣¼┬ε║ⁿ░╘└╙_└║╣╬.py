import random


class GameMZP:
    사용자 = str()  # 가위바위보 할 떄 내가 내는 것
    컴퓨터 = str()  # 가위바위보 할 때 컴퓨터가 내는 것
    점수 = int()
    공격수 = str()  # 점수통해서 -> 가위바위보 이긴 사람 골라냄 ( 묵찌빠의 첫 공격수가 된다)

    사용자_묵찌빠 = str()  # 묵찌빠떄 내가  내는 것
    컴퓨터_묵찌빠 = str()  # 묵찌빠떄 컴퓨터 내는 것

    새로운_공격수 = str()  # 묵찌빠 같지않을때 공격수 바뀔수도 있음



    def __init__(self, msg='Start Game!!'):        #굳이 안해도 됨(초기에 필요한 변수들을 할당하는 것  -> 가위바위보는 굳이 안넣어도 됨)  -> 선생님도 하신 이유는 내 이름이나 이런걸 넣으려고 하신 것
        print(msg)          #msg = 'start game' => 디폴트이므로 값없을때 자동으로 나오는 것


    def decide_score(self):  #3작업 한꺼번에 할 수 있게끔 묶어둔다.
        self.Make_MY()
        self.Make_COM()
        self.Win_Score()


    def Make_MY(self):  # 플레이어의 가위바위보 입력값
        사용자 = input('가위 바위 보를 내세요! ')
        if 사용자 == '가위':
            self.사용자 = 0
        elif 사용자 == '바위':
            self.사용자 = 1
        elif 사용자 == '보':
            self.사용자 = 2

        print('사용자는 {0}를 냈습니다.'.format(사용자))



    def Make_COM(self):  # 컴퓨터 가위바위보 (랜덤값)
        self.컴퓨터 = random.randint(0, 2)

        if self.컴퓨터 == 0:
            CODE = '가위'
        elif self.컴퓨터 == 1:
            CODE = '바위'
        elif self.컴퓨터 == 2:
            CODE = '보'
        print('컴퓨터는 {0}를 냈습니다. '.format(CODE))

    def Win_Score(self):  # 점수 결정한다.
        self.점수 = self.컴퓨터 - self.사용자
        return self.점수



    def Winner(self):  # 공격수 결정
        while True:
            if self.점수 in (-1, 2):
                self.공격수 = '사용자'
                break
            elif self.점수 == 0:  # 점수가 같을때 다시 돈다 ( 그 외에는 break )
                # self.Make_MY()
                # self.Make_COM()
                # self.Win_Score()
                self.decide_score()  #3가지를 한번에 묶어줌
            else:
                self.공격수 = '컴퓨터'
                break
        # return self.공격수
        print('\n묵찌빠 공격수는 {}입니다.'.format(self.공격수))




    def Make_MZP(self):  # 사용자 묵찌빠 입력값
        사용자_묵찌빠 = input('\n사용자님 묵찌빠 내세요!')  # 사용자 묵찌빠 입력값
        self.컴퓨터_묵찌빠 = random.randint(0, 2)  # 컴퓨터 묵찌빠 (랜덤값)

        if 사용자_묵찌빠 == '가위':
            self.사용자_묵찌빠 = 0
        elif 사용자_묵찌빠 == '바위':
            self.사용자_묵찌빠 = 1
        elif 사용자_묵찌빠 == '보':
            self.사용자_묵찌빠 = 2

        if self.컴퓨터_묵찌빠 == 0:
            CODE = '가위'
        elif self.컴퓨터_묵찌빠 == 1:
            CODE = '바위'
        elif self.컴퓨터_묵찌빠 == 2:
            CODE = '보'

        print('사용자 : {0} , 컴퓨터 ; {1}'.format(사용자_묵찌빠, CODE))

        # 가위 0 / 바위 1 / 보2




    def Change_Winner(self):  # 묵찌빠 점수가 다를때
        if self.사용자_묵찌빠 == 0 and self.컴퓨터_묵찌빠 == 1:  # (사용자 : 가위 / 컴퓨터 : 바위)
            self.새로운_공격수 = '컴퓨터'

        elif self.사용자_묵찌빠 == 0 and self.컴퓨터_묵찌빠 == 2:  # 가위 / 보
            self.새로운_공격수 = '사용자'

        elif self.사용자_묵찌빠 == 1 and self.컴퓨터_묵찌빠 == 2:  # 바위/ 보
            self.새로운_공격수 = '컴퓨터'

        elif self.사용자_묵찌빠 == 1 and self.컴퓨터_묵찌빠 == 0:  # 바위 / 가위
            self.새로운_공격수 = '사용자'

        elif self.사용자_묵찌빠 == 2 and self.컴퓨터_묵찌빠 == 0:  # 보/ 가위
            self.새로운_공격수 = '컴퓨터'

        elif self.사용자_묵찌빠 == 2 and self.컴퓨터_묵찌빠 == 1:  # 보/ 바위
            self.새로운_공격수 = '사용자'

        return self.새로운_공격수
        # print('공격수는 바뀌었습니다 , 공격수는 {}입니다'.format(self.새로운_공격수))







    def MZP_Winner(self):
        while True:
            if self.사용자_묵찌빠 == self.컴퓨터_묵찌빠:
                print("\n묵찌빠 끝 ! 승자는 {}입니다.".format(self.공격수))
                break
            else:
                self.공격수 = self.새로운_공격수
                print('\n이제 묵찌빠 공격수는 {}입니다.'.format(self.공격수))
                self.Make_MZP()
                self.Change_Winner()






# Step1 : 게임시작 -> 객체생성
msg = "게임시작"
G = GameMZP()

# Step2 : 가위바위보 점수결정
G.decide_score()        #이런식으로 써야 깔끔해짐
# G.Make_MY()  # 내꺼 
# G.Make_COM()  # 컴퓨터
# G.Win_Score()




G.Winner()  # 묵찌빠공격수결과값          #print('공격수는 {}입니다.'.format(G.공격수))
G.Make_MZP()  # 묵찌빠 내기
G.Change_Winner()
G.MZP_Winner()






