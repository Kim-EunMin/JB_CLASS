#클래스 정의
class MyClass:
    name = str()  #name 정의 안하고 이 후에 지정할 수 있음

    def sayHello(self):
        hello = 'Hello, ' + self.name  #위에서 name 선언하고 함수안에서 불러올땐 self 붙여주기
        print(hello)

#객체 생성, 인스턴스화
myClass = MyClass()        #객체생성을 한 것
myClass.name = '준영'     #값 채우는 것을 인스턴스화라고 생각하자.
myClass.sayHello()

#위에는 init 이 없기때문에 myClass.name = '준영'이라고 지정을 해줘야 print가 된다.
#매번 name 을 정의하는건 귀찮으니까 아예 클래스 부를때 이름도 같이 넣도록 하려면 -> init 을 사용하면 된다.



----------------------------------------------------------
#클래스초기화함수, __init__() 재정의
class MyClass:
    def __init__(self,name): #init -> 내장함수 인데 기능은 -> 초기화함수이다
        self.name = name

    def sayHello(self):
        hello = "hello, " + self.name
        print(hello)




#객체 생성, 인스턴스화
#myClass =MyClass()          => 오류발생 (init 있기때문에 선언할때 name 변수 써줘야함)
myClass =  MyClass('채영')    #초기화함수 있으니까 클래스 선언할때 변수도 같이 넣어줘야함.
myClass.sayHello()




