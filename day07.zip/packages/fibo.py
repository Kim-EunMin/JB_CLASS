#피보나치 수열을 위한 모듈

#fibo.py 라고 만들어두면 다른데서 import fibo 하고 호출이 된다.


def fib(n):
    """
    n 까지의 피보나치 수열을 출력하는 함수
    """
    a, b = 0, 1
    while b <n:
        print(b, end = ' ')
        a, b = b, a+b
    print()



def fib2(n):
    result = []
    a, b = 0, 1
    while b<n:
        result.append(b)
        a, b = b, a+b
    return result

