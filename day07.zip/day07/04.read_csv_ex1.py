def read_csv(filename):
    #파일데이터 읽어오기
    fp = open(filename, 'r', encoding='utf-8') #read 모드
    data = fp.read()
    fp.close()

    elements = []  #최종 리턴하기 위한 리스트 변수

    rows = data.split('\n')    #데이터를 한줄씩 구분하여 리스트로 담기
                               #줄바꿈으로 구분한다는 뜻


    for row in rows:  #한줄한줄씩 읽는다.
        fields = row.split(',')  #한줄 데이터를 콤마(,) 로 구분하여 리스트로 담기

        name = fields[0].strip()
        school = fields[1].strip()
        email = fields[2].strip()
        element = {
            '이름' : name,
            '학교' : school,
            '메일' : email
        }

        elements.append(element)  #한줄 데이터를 dict()형으로 변환 후 리스트에 추가
    return elements

filename ="./data/students.csv"
students = read_csv(filename)
print(stduents)
#print(students)
#한줄씩 보기 (깔끔하꼐)
for student in students:
    print(student)