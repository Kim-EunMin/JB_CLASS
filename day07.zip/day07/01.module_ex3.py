#방법3
from packages.fibo import fib as f1, fib2 as f2
f1(500)
reslut = f2(600)


