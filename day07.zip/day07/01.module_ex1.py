#대리님이 하신거 정리해보기


#방법1
from packages import fibo
#import packages.fibo as fibo


#directory 달라도 불러와짐


fibo.fib(20)


#directory 설정
# python 폴더안에  Lib 라고 있음.  (C:\Python\Python310\Lib)
# python.exe 도는 곳에 Lib 있음


# 내가 만든 패키지는 별도 폴더 만들어서 한꺼번에 모아두는게 좋다.

