#행이 몇개든 열이 몇개든 다 읽어오는 csv 함수


def read_csv(filename):
    fp = open(filename, 'r',encoding='utf-8')
    data = fp.read()  #전부
    fp.close()

    rows = data.split('\n')  # 한줄씩 끊어서 읽는다. -> [1행, 2행, 3행...]


#step1) 컬럼으로 사용되는 것, 실제 내용  구분하기
    cols = rows[0].split(',')   #첫번째줄은 컬럼이다. -> , 를 통해서 분리한다.
    #cols = [col.replace(' ','') for col in cols] #이렇게 하면 리스트에 담긴 컬럼값들의 빈칸을 공백으로 바꾼다.

    contents = rows[1:]          #컬럼제외하고 남은 것 (실제내용)
    final = []


    for row in contents:          #한줄한줄씩 읽는다.
        fields = row.split(',')  # ex. [1, 애플, apple, 스티븐잡스]

        if len(cols) != len(fields):      #csv사이에 공백인줄이 있더라도 ->  실행될 수 있게 (skip 하게 끔 해준다)
            continue      # 왜냐면 cols 는 항상 컬럼갯수인데, 공백인줄은 fields 값이 0이기 때문

        record = {}

        for idx in range(len(cols)):  #컬럼갯수
            key = cols[idx].strip()
            value = fields[idx].strip()
            #print(key,value)
            record[key] = value  #한줄이 dictionary 형태로 저장이 됨 (비어있던 record 에 값을 넣어줌)
            # -> {'랭킹': '1', '회사이름': '애플', '영문명': 'Apple', '창업자': '스티브잡스'}

        final.append(record)
    
    return final





#filename ="./data/company.csv"
filename ="./data/company.csv"
students = read_csv(filename)


#print(students)

#한줄씩 보기 (깔끔하꼐)
for student in students:
    print(student)