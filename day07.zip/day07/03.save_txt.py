
#'r' 대신 'w' 라고 쓴다.(read 모드 아니고 write 모드니까)
with open("./data/subject2.txt", 'w', encoding = 'UTF-8') as fp:  #subject2 라는 파일을 만든다.
    data = '데이터 분석과정'                #담을 데이터를 써준다.
    data += '\n Python Based programming'
    fp.write(data)



#write 한 txt 파일 읽엉오기
with open('./data/subject2.txt', 'r', encoding='UTF-8') as fp:
    data = fp.read()

print(data)

