fp = open('./data/test.txt','r')
print(fp.read())

# fp.close()
# print(fp.read())




#한글 있으면 읽어올때 에러가 생긴다. --> encoding 설정해주기
fp2 = open('./data/hello.txt','r',encoding='UTF-8')
print(fp2.read())




#close 안해주면 다른데서 사용못하는 문제가 생길 수 있음. -> with절 사용하면 closing 안해도 됨 (자동으로 close 됨)
with open('./data/hello.txt', encoding = 'utf-8') as fp:
    data = fp.read()
print(data)