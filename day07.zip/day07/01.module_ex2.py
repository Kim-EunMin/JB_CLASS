#방법2  : fibo 안에 있는 함수 다 풀러오고 싶을때
from packages.fibo import *  #-> fibo 안에 함수 다 가져옴

fib(300)  #fibo.fib 라고 안써도 됨
print(fib2(400))



