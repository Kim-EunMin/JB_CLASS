numbers = [10,11,12,13,4,5,6,7,8,9]

print('numbers :', numbers)

idx,sum = 0,0

while idx < len(numbers):
    num = numbers[idx]
    sum += num
    idx += 1

print('numbers의 합계는 %d 입니다.' % sum)






sigmal_color = ''

while sigmal_color != 'blue' and sigmal_color != 'red':  #빨강,파랑이 나올때까지 while 문이 돌아간다.
    sigmal_color = input('색을 영문으로 입력하세요 (blue/ red): ')

    if sigmal_color == 'blue':
        print("파란불입니다. ")
    elif sigmal_color == 'red':
        print("빨간불입니다. ")
    else:
        print('잘못된 색입니다.')
print('프로그램종료')

