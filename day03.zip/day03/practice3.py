import turtle as t

color = ['red','green','blue','yellow','purple','cyan','magenta','violet']

size  = 50  # 나아가는 길이
n     = 4   # 펜싸이즈
angle = 45  # 각도





for i in range(5):
    for j in range(8):
        t.pensize(n)
        t.color(color[j])
        t.forward(size)
        t.left(angle)
        size += 5
    n += 5


# for i in range(3):
#     for j in range(8):
#         if i == 3 and j ==4:
#             t.color('white')
#         else:
#             t.pensize(n)
#             t.color(color[j])
#             t.forward(size)
#             t.left(angle)
#             size += 5
#         n += 2





t.done()



# t.left(60)
# t.forward(100)
#
# t.left(60)
# t.forward(120)