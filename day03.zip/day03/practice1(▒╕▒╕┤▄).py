num = input('출력할 단을 입력해주세요.[2~9]')
print(num,'단 출력')
print('-'*30)

if int(num) < 10:
    for i in range(1,10):
        result = int(num) * i         #i 에는 int 안해도 int 임
        print(num,'*',i,'=',result)
else:
    #print('죄송합니다. 1~9 사이의 숫자를 입력해주세요')
    pass



# for i in range(1,10):
#     for j in range(1,10):
#         print('{} * {} = {}'.format(j,i,i*j), end='\t\t')
#     print()



