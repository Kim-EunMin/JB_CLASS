import turtle as t


num_circle = 10
radius = 180

t.bgcolor('blue')
t.color('yellow')
t.speed(0)




for _ in range(num_circle):      #변수 사용안해도 됨 -> _ 로 표시한다. (의미없는 변수 사용시 _로 표시)
    t.circle(radius)
    t.left(360/num_circle)

t.done()


#
# #
# import turtle
# t = turtle.Turtle()
# t.shape('turtle')
# 
# dot_distance = 50
# width = 5
# height = 4
# 
# t.penup()
# for y in range(height):        #y 랑 i 는 위의 _ 같은 존재
#     for i in range(width):
#         t.dot()
#         t.forward(dot_distance)
#     t.backward(dot_distance * width)
#     t.right(90)
#     t.forward(dot_distance) #아래로 한칸 띄어줌
#     t.left(90)
# turtle.done()