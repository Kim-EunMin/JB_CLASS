result = list(range(10))
print(result)

result = list(range(5,10))  #5,6,7,8,9
print(result)

result = list(range(1,10,2))
print(result)




