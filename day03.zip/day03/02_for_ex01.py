scope = list('abcde')

for x in scope:
    print(x) #element 들이 프린트된다.



