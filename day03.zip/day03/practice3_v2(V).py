import turtle as t

color = ['red','green','blue','yellow','purple','cyan','magenta','violet']

size  = 5   # 나아가는 길이
n     = 1   # 펜싸이즈
angle = 45  # 각도

# for i in range(5):
#     for j in range(8):
#         t.pensize(n)
#         t.color(color[j])
#         t.forward(size)
#         t.left(angle)
#         size += 5
#     n += 5


for i in range(45):
    t.pensize(n)
    t.color(color[i%8])
    t.forward(size)
    t.left(angle)
    size += 5
    n += 1

t.done()



