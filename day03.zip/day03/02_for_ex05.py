#중첩 for문

matrix = [[1,2,3],
          [4,5,6],
          [7,8,9]]

for x in range(3):
    for y in range(3):
        print('matrix[', x, '][',y, ']:',matrix[x][y], end = ', \t')
        # print('matrix[%d][%d] : '%(x, y), matrix[x][y], end= ' \t')
    print()  #한줄밑으로 내려서 쓰게 해주려고 작성 (end의 디폴트값이 뉴라인이니까)




