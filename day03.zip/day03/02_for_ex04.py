# for i in range(1,10,2):
#     mark = '*' * i
#     print(mark)



# width = 5
# for i in range(1,10,2):
#     mark   = '*' * i            # *이 들어가는 공간 구하기
#     width  -= 1                 # 빈칸 너비 구하기
#     blank_  = ' ' * width        # 빈칸 공간 나타내기
#
#     print(blank_, mark)
#
#
for i in range(1,10,2):
    mark =  '{space}{mark}'.format(
                space = ' ' * int((10-i)/2),  # int 니까 소수점 이하는 다 날라간다.
                mark  = '*' * i
                )
    print(mark)



for i in range(1,10,2):
    mark =  '{space}{mark}  {space}  i = {idx}'.format(
                space = ' ' * int((10-i)/2),  # int 니까 소수점 이하는 다 날라간다.
                mark  = '*' * i,
                idx   = i
                )
    print(mark)




