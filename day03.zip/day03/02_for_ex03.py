bts_members = ['RM', '슈가', '진', '제이홉', '지민', '뷔','정국']


print('for ex1')
num = 0
for member in bts_members:
    num += 1
    print('멤버%d ====> %s  \t\t(이름길이:%d)' % (num, member, len(member)))



print('\nfor ex2')


size = len(bts_members)  #7
for idx in range(size):
    print('멤버%d ---> %s  \t(이름길이:%d)' % (idx+1, bts_members[idx], len(bts_members[idx])))




