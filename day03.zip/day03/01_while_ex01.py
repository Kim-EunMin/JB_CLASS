#true가 아닐때까지 계속 반복


idx = 0
while idx<5:
    print(idx)
    idx  += 1      #idx = idx+1

print('프로그램 종료!')




num, sum = 1, 0

while True:
    sum += num  #sum = sum+num
    if sum>100:
        break
    else:
        num += 1
print('num값이 %d일때 while문 탈출!' % num)


