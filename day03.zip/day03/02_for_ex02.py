scope = list(range(1,100))

for num in scope:
    if num <= 10:
        if num % 2 ==0:
            pass                         # pass 는 큰 의미없다. -> 그냥 넘어가면 된다.
            print(num, 'is even number') #   -> 그래서 뒤에 print 문도 실행시켜준다.
        else:
            continue                     # continue -> 그 루프만 빠져나가게 한다.
            print(num, 'is odd number.') # -> 따라서 수행이 안된다.

    else:
        print(num,'is bigger than ten')
        break                            #break 문은 continue 와 다르게 반복문 전체를 탈출시킨다.
        print('after break')             # -> 따라서 수행이 안된다.




