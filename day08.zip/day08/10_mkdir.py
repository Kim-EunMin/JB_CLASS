#디렉터리 생성하기(osmkdir)   -> 폴더가 만들어진다.

import os
newfolder = input("새로 생성할 디렉터리 이름을 입력하세요:")

try:
    os.mkdir(newfolder)
    print('[%s] 디렉터리를 새로 생성했습니다.' % newfolder)
except Esception as e:
    print(e)          #오류발생시 예외처리 목적으로 사용하는 문 (try_except)


