#폴더인지 파일인지 구분하기 (os.pathisfile, os.pathisdir)


import os
from os.path import exists, isdir, isfile




files = os.listdir('..')
print('files :',files)
for file in files:
    if isdir(file):   #디렉터리인지 묻는것
        print('<DIR> %s' % file)



for file in files:
    if isfile(file):
        print('FILE : %s' % file)



