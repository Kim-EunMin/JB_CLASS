def write_txt(filepath):
    #텍스트 파일에 한줄씩 쓰기(writelines)

    count = 1
    data  = []
    print('파일에 내용을 저장하려면 내용을 입력하지말고 [Enter] 를 누르세요')

    while True:
        text = input('[%d] 파일에 저장할 내용을 입력하세요 : ' % count)
        if text == '':
            break
        data.append(text+'\n')
        count += 1

    f = open(filepath, 'w')  #write
    f.writelines(data)
    f.close()

    ret = 'TEXT 파일을 생성하였습니다.'
    return ret

#파일생성
filepath = 'txt/mydata.txt'
write_txt(filepath)

#파일읽기
f = open(filepath, 'r')
data = f.read()
f.close()

#print(data)