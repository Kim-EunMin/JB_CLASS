#디렉터리에 있는 파일목록얻기 (os.listdir, glob.glob)

import os,glob

folder = 'C:\Temp'

file_list1 = os.listdir(folder)
print(file_list1) #모든파일 가져옴





files = 'C:/Temp/*.txt'  #txt 만 가져옴.
file_list2 = glob.glob(files)
print(file_list2)


