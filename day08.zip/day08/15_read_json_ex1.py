import json

json_data = {
    'firstname' : '길동',
    'lastname'  : '홍',
    'age'       : 20,
    'country'   : '율도국'
}

# json_code = json.JSONEncoder().encode(json_data)
# print(json_code)
#1) '' 가 "" 바뀌었음
#2) 길동 대신 이상한 코드값으로 바뀌어 있다.


json_code = json.JSONEncoder(ensure_ascii=False).encode(json_data)  #한글로 나옴
print(json_code)



json_code = json.JSONDecoder().decode(json_code)
print(json_code)
print(type(json_code))
print(json_code['country'])




print('*'*50)
text = '{}{}은 {}살이고, {}에 살고 있습니다'.format(
    json_code['lastname'],
    json_code['firstname'],
    json_code['age'],
    json_code['country']
)
print(text)





