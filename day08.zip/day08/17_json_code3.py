#json 은 다차원이 많다. (아래와 같이)
import json

data = '''
{
    "name" : "홍길동",
    "dog"  : {
        "name" : "순둥이",
        "toys" : [
            {"name" : "뽀로로"},
            {"name" : "토마스"}
        ]
    }
}
'''
with open('data/person.json', 'w') as fp:
    fp.write(data)

with open('./data/person.json') as data_file:
    person = json.load(data_file)

#print(person)




text = '{}의 개 {}의 장난감은 {}, {}입니다.'.format(
    person["name"],
    person["dog"]["name"],
    person["dog"]["toys"][0]["name"],  #리스트는 인덱스/  #딕셔너리는 키로 불러온다.  (json이어도)
    person["dog"]["toys"][1]["name"]
)
print(text)
