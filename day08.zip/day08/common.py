# 이 파일은 01_factorial_ex.py 에서 import 해서 쓸 것이다.


def cs_num2(num):
    """
        숫자값에 콤마(,)를 붙여서 리턴해주는 함수
        param : num(숫자형)
        return : result(문자형)
    """
    num = str(num)  #문자형으로 변환
    rev_num = num[::-1]  #글자 거꾸로 나오게 한다.

    ret_num = str() #콤마찍어서 표현한 값

    for i in range(len(rev_num)):
        ret_num += rev_num[i]  #뒤에서 부터 한글자씩 ret_num 에 붙여나간다.
        if i%3 == 2:
            ret_num += ','  #3자리쓰고 콤마를 붙인다.

        result = ret_num[::-1]


    if result.startswith(','):  #앞글자가  콤마로 시작한다면
        result = result[1:]     #콤마를 제거한다.

    return result

def cs_num(num):
    n = '{:,}'.format(num)
    return n


