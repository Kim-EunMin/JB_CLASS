#파일이 존재하는지 체크하기 (os.pathexists)


import os
from os.path import exists

dir_name = input("새로 생성할 디렉터리 이름 ")

if not exists(dir_name):
    os.mkdir(dir_name)
    print('디렉터리 생성')

else:
    print('이미 존재함')