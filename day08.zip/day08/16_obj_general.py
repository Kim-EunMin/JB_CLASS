class Person:
    name = str()
    age = int()
    hometown = str()   #3가지 속성값

    def __init__(self, name,age, hometown):
        self.name = name
        self.age  = age
        self.hometown = hometown


    def to_string(self):
        str = '%s 의 나이는 %d 살이고, 고향은 %s 입니다' % (self.name, self.age, self.hometown)
        return str



theif1 = Person('홍길동',20, '율도국')
theif2 = Person('임꺽정', 35, '구월산')

print(theif1.to_string())
print(theif2.to_string())