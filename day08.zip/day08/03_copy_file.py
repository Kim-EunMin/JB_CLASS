#텍스트 파일 복사하기(read, write)

f = open('txt/.mydata.txt', 'r')  #read모드
h = open('txt/.mydata_copy.txt', 'w')

data = f.read()
h.write(data)  #복사가 됨

h.close()
f.close()


with open('txt/.mydata_copy.txt', 'r') as fp:
    data = fp.read()

print(data)