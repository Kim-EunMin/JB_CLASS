#파일 삭제하기(osremove)  # 파일삭제하면 복원이  어려움

from os import remove

target_file = './txt/.mydata_copy.txt'
k = input('[%s] 파일을 삭제하겠습니까? ([y]/n) ' % target_file)

if k =='y' or k=='':
    remove(target_file)
    print('[%s] 파일을 삭제햇습니다.'  % target_file)