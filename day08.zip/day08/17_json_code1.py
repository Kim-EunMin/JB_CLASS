import json



with open('./data/girlgroup.json', 'w') as fp:   #write 니까 생성하겠다. (위치는 data 폴더안)
    data = '["소녀시대", "애프터스쿨","에이핑크","걸스데이","우주소녀"]'
    fp.write(data)       #json 파일이 생김




with open('./data/girlgroup.json') as data_file:       #json 읽어온다.
    girlgroup = json.load(data_file)

print(girlgroup)
print(type(girlgroup))



text = '내가 좋아하는 걸그룹은 {}와 {}입니다.'.format(
    girlgroup[2], girlgroup[3])

print(text)


