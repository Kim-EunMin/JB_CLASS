#image 파일 복사

origin_img = './image/KJBANK.png'
copied_img = './image/KJBANK_copy.png'

bufsize = 2** 10  #bufsize 크기로 읽어온다.

f = open(origin_img, 'rb')
h = open(copied_img, 'wb')

data = f.read(bufsize)      #읽어서

while data:                  #write 해준다. (복사됨)
    h.write(data)
    data = f.read(bufsize)

h.close()
f.close()
