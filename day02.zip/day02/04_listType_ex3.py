#리스트 슬라이싱

rainbow = ['빨강','주황','노랑','초록','파랑','남색','보라']
print('\n무지개색깔 \t :', rainbow)

result = rainbow[2:5]  #2,3,4
print('rainbow[2:5] :', result)

result = rainbow[:3]   #0,1,2
print('rainbow[ :3] :', result)

result= rainbow[:]
print('rainbow[ : ] :', result)

result = rainbow[1::2]
print('rainbow[1::2] :', result)

result = rainbow[-3:]
print('rainbow[-3:] :', result)



#-------------------------------------------------------#

solarsys = ['태양','수성','금성','지구','화성','목성','토성','천왕성','지구']

#리스트에서 특정 요소의 위치구하기(index)
planet = '지구'
pos = solarsys.index(planet)
print('%s 행성은 태양계에서 %d번째에 위치하고 있습니다.' % (planet,pos))
 # --> 가장 먼저 나오는 값만 뿌려준다. (pos 는 3)

pos = solarsys.index(planet,5)  #5번째 이후의 인덱스값만 찾아나간다.
print('%s 행성은 태양계에서 %d번째에 위치하고 있습니다.' % (planet,pos))


