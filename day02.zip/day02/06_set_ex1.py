#세트형
# 1. 순서가 의미가 없음(인덱스로 불러올 수 없음)
# 2. 중복이 허용되지 않음



lang = {'Java','Java','Python','C++','Python'}
print(lang)    #중복은 제거되고 순서도 맘대로 출력됨
print(type(lang))
print('Python' in lang)



#세트형 집합 연산자
#a = list('abracadabra')    #---> 글자하나하나 element로 취급함
a = set('abracadabra'); print(a)
b = set('alacazm')    ; print(b)
print('합집합', a|b)
print('교집합', a&b)
print('차집합', a-b)
print('여집합', a^b)



#유니크한 값 뽑아내기
beast = ['lion','tiger','wolf','tiger','lion','bear','lion']
print(beast)

unique_beast = list(set(beast))
print(unique_beast)
print(sorted(unique_beast))  #정렬


print()
print()
#set자료형 -> 등록 및 삭제
beast = set(['lion','tiger','wolf','tiger','lion','bear','lion'])
beast.add('fox')
print(beast)

beast.remove('wolf')
print(beast)

beast.discard('fox')
print(beast)

#beast.remove('wolf')  -> keyError 없는 값 삭제하려고 하니까 오류 출력
beast.discard('wolf')  #-> remove 로는 에러나지만 discard 로는 에러가 나지 않는다
print(beast)




