#튜플
girl_group = ('트와이스','레드벨벳','에이핑크','걸스데이','우주소녀')
print(type(girl_group))
print(girl_group)
print(girl_group[:2])
print(girl_group[-2:])

#튜플값 변경시도(오류발생) -> 튜플은 한번 선언하면 값 변경이 안된다. (리스트랑 다름)
#girl_group[2] = '블랙핑크
#->  그럼에도 불구하고 값을 바꿔야 한다면 -> 리스트로 형변환한다.


girl_group = list(girl_group)
girl_group[2] = '블랙핑크'




data = (15,50)
width, height = data  # 할당됨




#튜플활용법
#기준값같은 것들은 튜플타입 좋음

