condition = False

if condition:
    print("조건을 충족함")

if not condition:  #if 뒤에가 true여야 실행이 되기때문에 두번째껏만 프린트가 된다.
    print("조건 충족 못함")

print()


num_a = 100
num_b = 200

if num_a > num_b:
    print('a가 b보다 크다')
else:
    print('a는 b랑 같거다 작다')

print()




a = 500
b = 300
max = 0
if a> b:
    print('숫자a 가 더 크다')
    max = a
elif a<b:
    print('숫자b 가 더 크다')
    max = b
else:
    print('숫자a 와 b 는 같다')
    max = a

print('max값=',max)






