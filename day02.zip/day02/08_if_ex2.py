#BMI 판정문

weight = float(input('체중(kg)은 ? '))
height = float(input('키(cm)는 ?'))


height = height/ 100
bmi    = weight/ (height*height)

result = ''                   #result를 선언한 이유는 -> 조건4개중에 하나라도 안걸리면 빈칸으로 표현가능
if bmi < 18.5:
    result = '마름'
elif (18.5<= bmi) and (bmi<25):  #18.5~25
    result = '보통'
elif (25<= bmi)   and (bmi<30):
    result = '가벼운 비만'
elif bmi >=30 :
    result = '심한 비만'

print('BMI :', bmi)
print("판정:" , result)

