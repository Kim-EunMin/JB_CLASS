import turtle


in_color = input('원의 색깔을 입력하세요 ')
is_filled = input("원을 색깔로 채울건가요?")

if in_color == 'R' or in_color == 'r':
    color = 'red'
elif in_color == 'G' or in_color == 'g':
    color = 'green'
elif in_color == 'B' or in_color =='b':
    color = 'blue'
else:
    color = 'black'

turtle.begin_fill()
turtle.color(color)
turtle.circle(100)

if is_filled in ('Y', 'y'):
    turtle.end_fill()
else:
    pass

turtle.done()