#중첩리스트

city = [
    ['서울', '도쿄', '베이징'],
    ['런던', '파리', '로마'  ],
    ['워싱턴','시카코','잭슨빌']
]

print('city      :', city)
print('city[0]   :', city[0])
print('city[1]   :', city[1])
print('city[-1]  :', city[-1])
print('city[0][0]:', city[0][0])
print('city[0][1]:', city[0][1])
print('city[0][2]:', city[0][2])
print('city[2][0]:', city[2][0])


