#사전형 생성  (key: value)

bans = {'잎새반' : '찬영이',
        '열매반' : '예영이',
        '햇살반' : '준영이',
        '열매반' : '채영이',}

print(type(bans))
print(len(bans))  #-> 키값 중복이 안됨

print(bans['열매반'])  #> key값 중복이 안됨 (채영이로 엎어치기 되어서 저장이 된다)



#추가
bans['꽃잎반'] = '희영이'
print('bans 추가', bans)

#변경
bans['잎새반'] = '서영이'  #서영이로 변경 됨
print('bans 변경', bans)

#삭제
del bans['햇살반']
print('bans 삭제', bans)



customer = {
    "name" : '김은민',
    "gender" : '여자',
    'email'  : 'kjb2120038@kjbank.com' ,
    'company' : '빅파이',
    'address' : '서울시 중구'
}

print(customer.keys())
print(customer.values())
print(customer.items())


for key, value in customer.items():
    print('')
    print('{} : {}'.format(key,value))