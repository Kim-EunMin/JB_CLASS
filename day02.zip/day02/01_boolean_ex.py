x = 4
y = 9

print(x==y)
print(x!=y)

print(x<y)
print(x>y)

print(int(True))
print(int(False))



test = '파이썬 프로그래밍 재미있다!'

result = test.startswith('파이썬')
print(result)

result = test.endswith('있다!')
print(result)

result= test.endswith('어려워요!')
print(result)

result = test.replace('파이썬','Python')
print(result)



