test = 'Python Programming is Interesting!'

result = test.upper()  #대문자로 변경
print(result)
print(result.isupper())

result = test.lower()  #소문자로 변경
print(result)
print(result.islower())


result='/'.join(test)  #문자열의 각 문자 사이에 '/' 문자 집어넣기
print(result)

