year = int(input("서기 몇 년 ? "))
is_leap = False  #윤년판정


if year % 4 == 0:
    if year % 100 == 0:
        if year % 400 == 0:
            is_leap = True
        else:
            is_leap = False
    else:
        is_leap = True
else:
    is_leap = False

if is_leap:  #is_leap 가 true 일때 출력된다
    print("윤년입니다")
else:
    print("윤년이 아닙니다")


print('*'*50)

is_leap = False
if year % 400 == 0:      #위에 있는 if 문 안에껏부터 써내려가기
    is_leap = True
elif year % 100 == 0:
    is_leap = False
elif year % 4 ==0:
    is_leap = True
else:
    is_leap = False

if is_leap:
    print("윤년")
else:
    print('no 윤년')



is_leap = (year % 400 ==0)or((year % 100 !=0)and(year%4==0))
if is_leap:
    print("윤년")
else:
    print("윤년아님")



