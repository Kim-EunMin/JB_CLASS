#리스트  -> 순서중요, 중복허용

bts_members = ['RM','슈가','진','제이홉','지민','뷔','정국']
print(bts_members)
print(type(bts_members))
print(len(bts_members))


print(bts_members[0])
print(bts_members[1])


print('리스트 멤버 호출(역순)')
print(bts_members[-1])  #맨뒤에꺼 호출
print(bts_members[-2])


