from random import randint



print('##### 로또번호 생성기 #####')
#ticket = 0
num_chk_list = list('0123456789')

while True:
    ticket = input('발급할 로또번호 티켓 갯수를 입력하세요.[1~5]')
    if ticket in num_chk_list:
        ticket = int(ticket)

        if (int(ticket) >= 1 and int(ticket) <= 5):
            print('%s 개의 로또번호 티켓을 주문하셨습니다.' % ticket)
            break
        else:
            print('한번에 발급할 수 있는 티켓은 최소 1개에서 최대 5개입니다. 다시입력해주세요')
    else:
        print('다시입력하세요.')


print('-'*30)

pick_number = list() # 이중으로 리스트 생성
for j in range(int(ticket)):
    number = set()
    while len(number) < 6:
        value = randint(1,45)
        number.add(value)
    pick_number.append(sorted(number))
print(pick_number)


for k in range(len(pick_number)):
    print('* 티켓 {} : '.format(k+1), pick_number[k])

final_result = {}
for i in range(len(pick_number)):
    final_result['티켓{}'.format(i+1)] = pick_number[i]

print(final_result)


