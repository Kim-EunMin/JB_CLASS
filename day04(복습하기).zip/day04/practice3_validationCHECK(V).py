

idx , gop, sum = 0, 0, 0
factorial = []
total_sum = []

#입력값이 숫자인지 확인해보기
num_chk_list = list('0123456789')  #숫자는 이 조합으로 구성되어있음

while True:
    key_in = input('숫자를 입력해 주세요. (1~100)')
    chk_num = True

    for char in key_in:  #들어오는 값(key_in) 을 한글자씩 뜯어서 본다.
        is_num = char in num_chk_list   #num_chk_list 안에 포함되어있는지 본다.(숫자이면 is_num은 True 로 저장됨)
        chk_num *= is_num  #(chk_num = chk_num * is_num)  -> 숫자면 chk_num 은 1이다.
        if not is_num:
            break  #is_num 이 false 이면 break 하고 for 문을 빠져나간다. 
        #print(char, is_num, chk_num)

    if chk_num: #chk_num 이 True 이면
        last_num = int(key_in)
        print("입력한 숫자:", last_num)
        break
    else:
        print("숫자가아니다")





#입력값이 숫자인경우 , 미션수행
print('-'*100)
print(str(last_num) + '까지의 팩토리얼 테이블 구하기!!')
print('-'*100)

