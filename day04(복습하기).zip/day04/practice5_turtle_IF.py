#숫자값을 입력받아 다각형 그려보기
import turtle

var1 = int(input('변의 수를 입력해주세요?[3-8]'))
var2 = int(input('한변의 길이를 입력해주세요[100-200]'))

angle = 360/var1
c_mod = var1 % 3  #나머지 활용


color = 'red' if c_mod ==0 else 'green' if c_mod ==1 else 'blue'  #if 문 표현하기
 #아래와 같다.
# if c_mod == 0:
#     color = 'red'
# else:
#     if c_mod == 1:
#         color = 'green'
#     else:
#         color = 'blue'



turtle.begin_fill()
turtle.pensize(10)
turtle.color(color)

for _ in range(var1):
    turtle.forward(var2)
    turtle.left(angle)
turtle.done()





