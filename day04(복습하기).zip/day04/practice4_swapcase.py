text = input('영어 대소문자로 이루어진 문장을 입력하세요')
#대문자로 변환
print('모두 대문자로 출력\n' + text.upper())

#소문자로 변환
print('모두 소문자로 출력\n' + text.lower())


new_s = str()  #신규 문자열 형 변수 선언

for c in text:  #한글자씩 가져온다.
    if c.islower():     #소문자이면
        new_s += c.upper()  #c 를 대문자로 바꿔서 new_s 에 붙인다.
    else:
        new_s += c.lower()  #소문자로 바꿔서 new_S 에 붙인다.

print('대소문자바꿔서 출력\n'+new_s)

# print(text.swapcase())


