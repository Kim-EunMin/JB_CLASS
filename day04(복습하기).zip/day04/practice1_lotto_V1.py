from random import randint
print('##### 로또번호 생성기 #####')
ticket = input('발급할 로또번호 티켓 갯수를 입력하세요.[1~5] =>')

while ticket not in ('1','2','3','4','5'):        #1,2,3,4,5가 아닐때  계속 반복한다.
        print('한번에 발급할 수 있는 티켓은 최소 1개에서 최대 5개입니다. 다시입력해주세요')
        ticket = input('발급할 로또번호 티켓 갯수를 입력하세요.[1~5] =>')
        
print('{}개의 로또번호 티켓을 주문하셨습니다'.format(ticket)) #while 문이 false 일때 실행



print('-' * 100)
final_result = {}
for i in range(int(ticket)):
    pick_number = [randint(1,45),randint(1,45),randint(1,45),randint(1,45),randint(1,45),randint(1,45)]
    print('* 티켓{} : {}'.format(i+1,pick_number))
    final_result['티켓{}'.format(i+1)] = pick_number  #빈 딕셔너리 안에 데이터 집어넣기
print('-' * 100)




print('final_ticket = ',final_result)

