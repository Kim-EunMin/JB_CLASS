cols = 5           #한줄에 몇개 넣을지
rows = int(8/cols) + 1
w_space = '\t\t'*2

for row in range(rows):  #0,1,2
    dans = list()
    for col in range(cols):
        dan = (row * cols) + col + 2
        dans.append(dan)

    for num in range(10):
        for dan in dans:
            if dan > 9:
                continue   #9단이 넘어가면 pass 한다.

            if num<1:
                print('{} 단 \t'.format(dan), end=w_space)
            else:
                gugutext = '{} x {} = {}'.format(dan, num, dan*num)
                print(gugutext, end=w_space)
        print()

    print()