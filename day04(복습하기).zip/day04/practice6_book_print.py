books = list()     #1단계 : 책목록 선언


books.append({'제목':'파이썬 프로그램', '출판연도':'2016', '출판사':'A', '쪽수':200, '추천유무':False})
books.append({'제목':'플랫폼 비즈니스', '출판연도':'2013', '출판사':'B', '쪽수':584, '추천유무':True})
books.append({'제목':'빅데이터 마케팅', '출판연도':'2014', '출판사':'A', '쪽수':296, '추천유무':True})
books.append({'제목':'외식경영 전문가', '출판연도':'2010', '출판사':'B', '쪽수':526, '추천유무':False})
books.append({'제목':'십억만 벌어보자', '출판연도':'2013', '출판사':'A', '쪽수':248, '추천유무':True})

#print(len(books))


many_page = list()        #책 리스트 선언
recommends = list()       #책 리스트 선언
all_pages = int()         #전체 쪽수 변수 선언
pub_companies = set()     #출팝사 집합 선


# for book in books:
#     if book['쪽수'] > 250:
#         many_page.append(book['제목'])  #250page 가 넘으면  many_page 라는 빈리스트안에 추가한다.


# for book in books:
#     if book['추천유무']:
#         recommends.append(book['제목'])
#     else:
#         continue


# for book in books:
#     all_pages += book['쪽수']
#
#
# for book in books:
#     pub_companies.add(book['출판사'])


for book in books:
    if book['쪽수'] > 250:
        many_page.append(book['제목'])
    if book['추천유무']:                # boolean 타입이니까 굳이 '==True'를 안써도 됨 (자동으로 true 인 애들만 가져온다)
        recommends.append(book['제목'])
    all_pages += book['쪽수']
    pub_companies.add(book['출판사'])


print('쪽수가 250 쪽 넘는 책 리스트:', many_page)
print('내가 추천하는 책 리스트:', recommends)
print('내가 읽은 책 전체 쪽수:', all_pages)
print('내가 읽은 책의 출판사 목록:', pub_companies)



#한줄로 표현하기
many_page2  = [book['제목'] for book in books if book['쪽수'] > 250]
recommends2 = [book['제목'] for book in books if book['추천유무']]
pub_companies2 = { book['출판사'] for book in books}
all_pages2 = sum([book['쪽수'] for book in books])


#print(many_page2, recommends2,pub_companies2,  all_pages2)


