text = input("영어 문장을 입력하세요\n")

final = str() #거꾸로 뒤집은 문장을 여기에 넣을 것이다.


for i in range(len(text)):       #글자하나씩 가져옴
    reverse_idx = (i+1) * -1     #idx를 거꾸로 불러오게 함 (글자가 5글자이면 -> -1,-2,-3,-4,-5가 나옴)
    #print(text[reverse_idx])
    final += text[reverse_idx]

print(text+'\n'+final)




#방법2
# for i in range(len(text)-1,-1,-1):
#     final += text[i]
# print(final)


#방법3
#print(text[::-1])  #인덱스 사용법으로 역순출력이 가능 (처음부터 끝까지 -1칸 간격으로 간다)