print('hello, Python World!!!')

print('반갑습니다. \n파이썬세계로 온 것을 환영합니다.')
print( "문자는 반드시 인용부호(\"\" 혹은 \'\')로 감싸야합니다.")

#"" 사이에 "문자를 쓰고 싶다면 -> \ 부호를 같이 써주면 된다.
#또는      " 문자를 쓰고싶다면 > 양끝에 ''를 써주면 된다.

#print('she said, 'I play the violin'.')  #마찬가지로 '' 사이에 ''부호를 쓸 수가 없으므로 아래처럼 표현한다.
print("she said, 'I play the violin'.")    # 방법1
print('she said, \'I play the violin\'.')  # 방법2



