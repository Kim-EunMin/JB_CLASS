#문자 붙여쓰기 -> + 부호사용한다.

name = '홍길동'
greeting = '안녕'
text = name + '님,' + greeting + '하세요'
print(text)







