order = input('강남카페입니다. \n 무엇을 주문하실까요?')
count = input('몇잔을 드릴까요?')

price = 4500
cost = price * int(count)    ## count는 input 을 씀으로써 문자변수이기 때문에 int 를 써줘야한다.


print('{} {}잔을 주문하셨습니다. \n결제하실 금액은 {}입니다~^^ '.format(order, count, cost))
